import sys


def main():
    try:
        if len(sys.argv) == 3 and sys.argv[1].lower() == 'create':
            create_quiz(sys.argv[2])
        elif len(sys.argv) == 3 and sys.argv[1].lower() == 'run':
            run_quiz(sys.argv[2])
        else:
            sys.exit("Invalid parameters: 'python quiz.py <create>/<run> <file>")
    except SystemExit as i:
        print(f'SystemExit: {i}')
        sys.exit()


def display_truefalse(question, answer):
    print(question)
    user_input = input('Is this statement true or false? (T/F): ').upper()
    if user_input == answer:
        print('Correct!\n--')
        return True
    else:
        print(f'Incorrect. The answer is {answer}\n--')
        return False


def display_multiplechoice(question, answer, choices):
    print(question)
    if len(choices) == 0:
        int('valueError')
    for i in range(len(choices)):
        print(f'{i+1}) {choices[i]}')
    user_input = input('Enter your selection: ')
    if user_input == answer:
        print('Correct\n--')
        return True
    else:
        print(f'Incorrect. The answer is {answer}\n--')
        return False


def display_question(line):
    quiz_data = line.split(',')
    if quiz_data[0] == 'MC':
        return display_multiplechoice(quiz_data[1], quiz_data[2], quiz_data[3:])
    elif quiz_data[0] == 'TF':
        return display_truefalse(quiz_data[1], quiz_data[2])


def run_quiz(filename):
    with open(filename, 'r') as raw_quiz:
        quiz = raw_quiz.read()
        quiz = quiz.split('\n')
        del quiz[-1]
    correct_count = 0
    for i in range(len(quiz)):
        if display_question(quiz[i]):
            correct_count += 1
    print(f'You have {correct_count}/{len(quiz)} ({(correct_count/len(quiz))*100}%) correct.')


def create_truefalse():
    return f'TF,{input("Enter the question: ")},{input("Enter the answer (T or F): ").upper()}'


def create_multiplechoice():
    mc_str = ''
    mc_list = ['MC', input('Enter the question: ')]
    while mc_list[-1] != '':
        mc_list.append(input('Enter a possible answer (ENTER to end): '))
    del mc_list[-1]
    print(mc_list[1])
    for i in range(len(mc_list)- 2):
        print(f"{i + 1}) {mc_list[i+2]}")
    mc_list.insert(2, input('Which one is the correct answer: '))
    for i in range(len(mc_list)):
        mc_str += mc_list[i] + ','
    return mc_str[:-1]


def create_question():
    question_input = input('What type of question do you want to create (MC, TF or ENTER to end)')
    if question_input.lower() == 'mc':
        return create_multiplechoice()
    elif question_input.lower() == 'tf':
        return create_truefalse()
    elif question_input == '':
        return -1


def create_quiz(filename):
    f = open(filename, 'w')
    question = ''
    quiz = ''
    while question != -1:
        question = create_question()
        if question != -1:
            quiz += question + '\n'
    if len(quiz) > 0:
        f.write(quiz)
    f.close()


if __name__ == '__main__':
    main()
