# Creating database
DROP DATABASE IF EXISTS JungleBooks;
CREATE DATABASE JungleBooks;
USE JungleBooks;

# Creating book table
DROP TABLE IF EXISTS Book;
CREATE TABLE Book(
    BookID INTEGER AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(80) NOT NULL,
    Summary VARCHAR(1000) NOT NULL,
    Author VARCHAR(32) NOT NULL,
    ISBN VARCHAR(24) NOT NULL,
    Price FLOAT NOT NULL
);

# Creating Category table
DROP TABLE IF EXISTS Category;
CREATE TABLE Category(
    CategoryID INTEGER AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(32) NOT NULL
);

# Creating Book Category associate table
DROP TABLE IF EXISTS BookCategory;
CREATE TABLE BookCategory(
    BookID INTEGER NOT NULL,
    CategoryID INTEGER NOT NULL
);

# Creating customer table
DROP TABLE IF EXISTS Customer;
CREATE TABLE Customer(
    CustomerID INTEGER AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(32) NOT NULL,
    LastName VARCHAR(32) NOT NULL,
    BillingAddress VARCHAR(80) NOT NULL,
    ShippingAddress VARCHAR(80) NOT NULL,
    PhoneNumber CHAR(11) NOT NULL,
    Email VARCHAR(80) NOT NULL,
    Username VARCHAR(32),
    Password VARCHAR(32) # Save it as plaintext, what could go wrong.
);

# Creating order table
DROP TABLE IF EXISTS PlacedOrder;
CREATE TABLE PlacedOrder(
    OrderID INTEGER AUTO_INCREMENT PRIMARY KEY,
    CustomerID INTEGER NOT NULL,
    OrderDate DATETIME NOT NULL,
    ShipDate DATETIME,
    Status VARCHAR(32) NOT NULL,
    Subtotal FLOAT NOT NULL,
    Tax FLOAT NOT NULL,
    Total FLOAT NOT NULL
);

# Creating Order info table
DROP TABLE IF EXISTS OrderInfo;
CREATE TABLE OrderInfo(
    InfoID INTEGER AUTO_INCREMENT PRIMARY KEY,
    BookID INTEGER NOT NULL,
    OrderID INTEGER NOT NULL,
    Quantity INT(3) NOT NULL,
    Subtotal FLOAT NOT NULL
);

#Adding in foreign key constraints
ALTER TABLE BookCategory
    ADD CONSTRAINT FK_BookCategory_BookID FOREIGN KEY (BookID) REFERENCES Book(BookID),
    ADD CONSTRAINT FK_BookCategory_CategoryID FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID);

ALTER TABLE PlacedOrder
    ADD CONSTRAINT FK_PlacedOrder_CustomerID FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID);

ALTER TABLE OrderInfo
    ADD CONSTRAINT FK_OrderInfo_BookID FOREIGN KEY (BookID) REFERENCES Book(BookID),
    ADD CONSTRAINT FK_OrderInfo_OrderID FOREIGN KEY (OrderID) REFERENCES PlacedOrder(OrderID);

# Adding books
INSERT INTO Book
    (BookID, Title, Summary, Author, ISBN, Price)
VALUES
(1, 'The Fellowship of the Ring', 'The future of civilization rests in the fate of the One Ring, '
'which has been lost for centuries. Powerful forces are unrelenting in their search for it. But fate has placed it in '
'the hands of a young Hobbit named Frodo Baggins , who inherits the Ring and steps into legend. A daunting '
'task lies ahead for Frodo when he becomes the Ringbearer - to destroy the One Ring in the fires of Mount Doom where it'
' was forged.', 'J.R.R.Tolkien', '9780618002221', 10.88),
(2, 'The Hitchhiker''s Guide to the Galaxy' , 'One Thursday lunchtime the Earth gets'
'unexpectedly demolished to make way for a new hyperspace bypass. It''s the final straw for Arthur Dent, who has '
'already had his house bulldozed that morning. But for Arthur, that is only the beginning. In the seconds before '
'global obliteration, Arthur is plucked from the planet by his friend Ford Prefect - and together the pair venture out '
'across the galaxy on the craziest, strangest road trip of all time' ,'Douglas Adams' ,'9780330508117' ,13.22),
(3, 'Python Pocket Reference: Python In Your Pocket', 'Updated for both Python 3.4 and 2.7,'
'this convenient pocket guide is the perfect on-the-job quick reference. You’ll find concise, need-to-know information '
'on Python types and statements, special method names, built-in functions and exceptions, commonly used standard '
'library modules, and other prominent Python tools. The handy index lets you pinpoint exactly what you need.',
'Mark Lutz', '9781449357016', 15.45);

INSERT INTO Category
    (CategoryID, CategoryName)
VALUES
(1, 'Fiction'),
(2, 'Non-Fiction'),
(3, 'Fantasy'),
(4, 'Science-Fiction'),
(5, 'Educational'),
(6, 'Programming'),
(7, 'Database');

INSERT INTO BookCategory
    (BookID, CategoryID)
VALUES (1, 1),
       (1, 3),
       (2, 1),
       (2, 4),
       (3, 2),
       (3, 5),
       (3, 6);
# Adding Customers
INSERT INTO Customer
    (CustomerID, FirstName, LastName, BillingAddress, ShippingAddress, PhoneNumber, Email, Username, Password)
VALUES
(1, 'Alexander', 'Blackwood', '333 Somewhere Ave, Fredericton NB E3A0D6', '333 Somewhere Ave, Bridgewater NS B4V 3J3',
'19021114434', '1manfewwords@yahoo.ca', NULL, NULL),
(2, 'James', 'Hawk', '123 Something Road, Fredericton NB E3A5F7', '123 Something Road, Halifax NS B3B 2V6', '19025551234',
 'blindlysaving@gmail.com', 'Protectoret', 'McBonalds2123'),
(3, 'Julien', 'Evans', '1337 Someplace Drive, Bridgewater NS B4V3J3', '1337 Someplace Drive, Bridgewater NS B4V3J3',
 '19023521133', '2angry2eat@duckduckgo.com', 'TheGourmet', 'H3roM@t3ri@l'),
(4, 'Markus', 'Nelson', '666 Random Street, Halifax NS, B3K3V3', '777 Notrandom Street, Halifax NS B3K2F4',
'19027894561', '30poundpride@hotmail.com', 'Pride', 'CharmedBane209');

# Creating orders
INSERT INTO PlacedOrder
    (OrderID, CustomerID, OrderDate, ShipDate, Status, Subtotal, Tax, Total)
VALUES
(1, 1, '2019-11-01T00:00:00', '2019-11-12T00:00:00', 'IN PROGRESS', 39.55 ,1.15 ,Subtotal * Tax),
(2, 2, '2019-11-23T00:00:00', '2019-11-24T00:00:00', 'IN PROGRESS', 10.88 ,1.15 ,Subtotal * Tax),
(3, 3, '2019-11-25T00:00:00', NULL, 'PENDING CONFIRMATION', 235.34 ,1.15 ,Subtotal * Tax);

INSERT INTO OrderInfo
    (InfoID, BookID, OrderID, Quantity, Subtotal)
VALUES
(1, 1, 1, 1, 10.88 * Quantity),
(2, 2, 1, 1, 13.22 * Quantity),
(3, 3, 1, 1, 15.45 * Quantity),
(4, 1, 2, 1, 10.88 * Quantity),
(5, 1, 3, 5, 10.88 * Quantity),
(6, 2, 3, 2, 13.22 * Quantity),
(7, 2, 3, 10, 15.45 * Quantity);

# Deleting the second order
DELETE FROM OrderInfo
WHERE OrderID = 2;
DELETE FROM PlacedOrder
WHERE OrderID = 2;

# Updating first order to complete
UPDATE PlacedOrder
SET Status = 'COMPLETE'
WHERE OrderID = 1;

# Adding one more copy of the second book to the third order
UPDATE OrderInfo
SET Quantity = Quantity + 1
WHERE  OrderID = 3 AND BookID = 2;

UPDATE PlacedOrder
SET Subtotal = Subtotal + 13.22
WHERE OrderID = 3;

# Display customers that have no orders
SELECT C.*
FROM Customer C LEFT OUTER JOIN PlacedOrder P
ON C.CustomerID = P.CustomerID
WHERE P.CustomerID IS NULL;

# Display book information on books related to databases
SELECT B.Title, B.Author, B.ISBN, B.Price
FROM Book B INNER JOIN BookCategory BC
ON B.BookID = BC.BookID
WHERE BC.CategoryID = 7 OR B.Title LIKE '%database%'
GROUP BY B.BookID;

# Display emails that have outstanding orders
SELECT C.Email
FROM Customer C INNER JOIN PlacedOrder P
ON C.CustomerID = P.CustomerID
WHERE P.ShipDate IS NULL;

# Display order info of all orders that contain more than one copy of one book.
SELECT P.*
FROM PlacedOrder P INNER JOIN OrderInfo O
ON P.OrderID = O.OrderID
WHERE O.Quantity > 1;

# Display the order number and total number
SELECT O.OrderID, SUM(O.Subtotal) AS TOTAL_SUBTOTAL
FROM OrderInfo O
GROUP BY O.OrderID;

#Display order number, customer and total cost
SELECT O.OrderID, C.CustomerID, SUM(O.Subtotal) * 1.15 AS TOTAL_COST
FROM PlacedOrder P
INNER JOIN OrderInfo O ON P.OrderID = O.OrderID
INNER JOIN Customer C ON P.CustomerID = C.CustomerID
GROUP BY C.CustomerID;
