import discord
import random

client = discord.Client()

@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))
    global feats, boons, banes, perks, flaws
    feats, boons, banes, perks, flaws = await fileBoot()
async def fileBoot():
    featFile = open('Feats.txt', 'r')
    featList = await OLpars(featFile.read())
    featFile.close()

    boonFile = open('Boons.txt', encoding="utf8")
    boonList = await OLpars(boonFile.read())
    boonFile.close()

    baneFile = open('Banes.txt', encoding="utf8")
    baneList = await OLpars(baneFile.read())
    boonFile.close()

    perkFile = open('Perks.txt', encoding="utf8")
    perkList = await OLpars(perkFile.read())
    perkFile.close()

    flawFile = open('Flaws.txt', encoding="utf8")
    flawList = await OLpars(flawFile.read())
    flawFile.close()

    return featList, boonList, baneList, perkList, flawList
async def OLpars(f):
    f = f.split('\n')
    for i in range(len(f)):
        f[i] = f[i].replace('#', '\n')
        f[i] = f[i].split('/')
        for x in range(len(f[i])):
            f[i][x] = f[i][x].replace('^', '/')
    return f


@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content.startswith('e!') or message.content.startswith('E!'):
        await e(message)
async def e(message):
    msgCon = message.content[3:].lower()
    if msgCon == 'help' or msgCon == '?':
        helpMessage = 'e! feat <arg>/random/all - Pulls info on Feats\ne! boon <arg>/random/all - Pulls info on Boons\ne! bane <arg>/random/all - Pulls info on Banes\ne! perk <arg>/random/all - Pulls info on Perks\ne! flaw <arg>/random/all - Pulls info on Flaws'
        await message.channel.send(helpMessage)
    
    elif msgCon.startswith('feat'):
        await feat(message)

    elif msgCon.startswith('boon'):
        await boon(message)

    elif msgCon.startswith('bane'):
        await bane(message)

    elif msgCon.startswith('perk'):
        await perk(message)
    
    elif msgCon.startswith('flaw'):
        await flaw(message)

    else:
        await message.channel.send('Invalid entry: Type *e! help* or *e! ?* for help.')


async def feat(message):
    noFeat = True
    msgCon = message.content[3:].lower()
    msgCon = msgCon[5:]
    if msgCon == 'all':
        allFeats = ''
        for i in range(1, len(feats)):
            allFeats += feats[i][0] + '\n'
        await message.channel.send(allFeats)
        noFeat = False
    
    elif msgCon == 'random':
        await featOutput(message, feats[random.randint(1, len(feats))])
        noFeat = False
    
    else:
        for i in range(len(feats)):
            if msgCon == feats[i][0].lower():
                await featOutput(message, feats[i])
                noFeat = False

    if noFeat:
        await message.channel.send('Feat not found type *e! feat all* for a list of feats')
async def featOutput(message, featInfo):
    if len(featInfo) == 4:
        outp = (f"**{featInfo[0]} ({featInfo[1]})**\n*Effect:*\n{featInfo[2]}\n*Prerequisites:*\n{featInfo[3]}")
    else:
        outp = (f"**{featInfo[0]} ({featInfo[1]})**\n*Effect:*\n{featInfo[2]}\n*Prerequisites:*\n{featInfo[3]}\n*Special:*\n{featInfo[4]}")
    if len(outp) > 4000:
        await message.channel.send(f"{outp[0:1999]}")
        await message.channel.send(f"{outp[1999:2999]}")
        await message.channel.send(outp[2999:])
    elif len(outp) > 2000:
        await message.channel.send(f"{outp[0:1997]}")
        await message.channel.send(outp[1997:])
    else:
        await message.channel.send(outp)

async def boon(message):
    noBoon = True
    msgCon = message.content[3:].lower()
    msgCon = msgCon[5:]
    if msgCon == 'all':
        allBoons = ''
        for i in range(1, len(boons)):
            allBoons += boons[i][0] + '\n'
        await message.channel.send(allBoons)
        noBoon = False
    
    elif msgCon == 'random':
        await boonOutput(message, boons[random.randint(1, len(boons))])
        noBoon = False
    
    else:
        for i in range(len(boons)):
            if msgCon == boons[i][0].lower():
                await boonOutput(message, boons[i])
                noBoon = False
    
    if noBoon:
        await message.channel.send('Boon not found type *e! boon all* for a list of boons')
async def boonOutput(message, boonInfo):
    if len(boonInfo) == 6:
        outp = (f"**{boonInfo[0]} ({boonInfo[1]})**\n*Invocation Time:*\n{boonInfo[2]}\n*Duration:*\n{boonInfo[3]}\n*Attributes:*\n{boonInfo[4]}\n*Effect:*\n{boonInfo[5]}")
    else:
        outp = (f"**{boonInfo[0]} ({boonInfo[1]})**\n*Invocation Time:*\n{boonInfo[2]}\n*Duration:*\n{boonInfo[3]}\n*Attributes:*\n{boonInfo[4]}\n*Effect:*\n{boonInfo[5]}\n*Special:*\n{boonInfo[6]}")
    if len(outp) > 2000:
        await message.channel.send(f"{outp[0:1995]}")
        await message.channel.send(f"{outp[1995:]}")
    else:
        await message.channel.send(outp)

async def bane(message):
    noBane = True
    msgCon = message.content[3:].lower()
    msgCon = msgCon[5:]
    if msgCon == 'all':
        allBanes = ''
        for i in range(1, len(banes)):
            allBanes += banes[i][0] + '\n'
        await message.channel.send(allBanes)
        noBane = False
    
    elif msgCon == 'random':
        await baneOutput(message, banes[random.randint(1, len(banes))])
        noBane = False
    
    else:
        for i in range(len(banes)):
            if msgCon == banes[i][0].lower():
                await baneOutput(message, banes[i])
                noBane = False
    if noBane:
        await message.channel.send('Bane not found type *e! bane all* for a list of banes')
async def baneOutput(message, baneInfo):
    if len(baneInfo) == 6:
        outp = (f"**{baneInfo[0]} ({baneInfo[1]})**\n*Duration:*\n{baneInfo[2]}\n*Attack Attributes:*\n{baneInfo[3]}\n*Attack:*\n{baneInfo[4]}\n*Effect:*\n{baneInfo[5]}")
    else:
        outp = (f"**{baneInfo[0]} ({baneInfo[1]})**\n*Duration:*\n{baneInfo[2]}\n*Attack Attributes:*\n{baneInfo[3]}\n*Attack:*\n{baneInfo[4]}\n*Effect:*\n{baneInfo[5]}\n*Special:*\n{baneInfo[6]}")
    if len(outp) > 2000:
        await message.channel.send(f"{outp[0:1999]}")
        await message.channel.send(f"{outp[1999:]}")
    else:
        await message.channel.send(outp)

async def perk(message):
    noPerk = True
    msgCon = message.content[3:].lower()
    msgCon = msgCon[5:]
    if msgCon == 'all':
        allPerks = ''
        for i in range(1, len(perks)):
            allPerks += perks[i][0] + '\n'
        await message.channel.send(allPerks)
        noPerk = False
    
    elif msgCon == 'random':
        rngPerk = random.randint(1, len(perks))
        await message.channel.send(f"**{perks[rngPerk][0]}:**\n{perks[rngPerk][1]}")
        noPerk = False
    
    else:
        for i in range(len(perks)):
            if msgCon == perks[i][0].lower():
                await message.channel.send(f"**{perks[i][0]}:**\n{perks[i][1]}")
                noPerk = False
    if noPerk:
        await message.channel.send('Perk not found type *e! perk all* for a list of perks')

async def flaw(message):
    noFlaw = True
    msgCon = message.content[3:].lower()
    msgCon = msgCon[5:]
    if msgCon == 'all':
        allFlaws = ''
        for i in range(1, len(flaws)):
            allFlaws += flaws[i][0] + '\n'
        await message.channel.send(allFlaws)
        noFlaw = False
    
    elif msgCon == 'random':
        rngFlaw = random.randint(1, len(flaws))
        await message.channel.send(f"**{flaws[rngFlaw][0]}:**\n{flaws[rngFlaw][1]}")
        noFlaw = False
    
    else:
        for i in range(len(flaws)):
            if msgCon == flaws[i][0].lower():
                await message.channel.send(f"**{flaws[i][0]}:**\n{flaws[i][1]}")
                noFlaw = False
    if noFlaw:
        await message.channel.send('Flaw not found type *e! flaw all* for a list of flaws')

client.run('')
