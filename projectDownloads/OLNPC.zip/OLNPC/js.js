fetch('https://openlegend.heromuster.com/api/npc')
.then((resp) => resp.json()) // Transform the response into json
.then(function(data) {
    console.log(data);
    // Query selecting
    let name = document.querySelector('#name');
    let description = document.querySelector('#description');
    let level = document.querySelector('#level');
    let guard = document.querySelector('#guard');
    let toughness = document.querySelector('#toughness');
    let resolve = document.querySelector('#resolve');
    let hp = document.querySelector('#hp');
    let initiative = document.querySelector('#initiative');
    let speed = document.querySelector('#speed');
    let attacks = document.querySelector('#attacks');
    let attributes = document.querySelector('#attributes');
    let banes = document.querySelector('#banes');
    let boons = document.querySelector('#boons');
    let disp = document.querySelector('#display');
    let PL1 = document.querySelector('#PL1');
    let PL2 = document.querySelector('#PL2');
    let PL3 = document.querySelector('#PL3');
    let PL4 = document.querySelector('#PL4');
    let PL5 = document.querySelector('#PL5');
    let PL6 = document.querySelector('#PL6');
    let PL7 = document.querySelector('#PL7');
    let PL8 = document.querySelector('#PL8');
    let PL9 = document.querySelector('#PL9');
    let PL10 = document.querySelector('#PL10');
    // Setting data
    npc = data.success;
    name.textContent = npc.name;
    description.textContent = npc.description;
    level.textContent = 'Level: ' + npc.level;
    guard.textContent = 'Guard: ' + npc.defenses.guard;
    toughness.textContent = 'Toughness: ' + npc.defenses.toughness;
    resolve.textContent = 'Reslove: ' + npc.defenses.resolve;
    hp.textContent = 'HP: ' + npc.hp;
    if (npc.initiative.dice!='d20'){
        initiative.textContent = 'Initiative: ' + 'd20 ' + npc.initiative.dice;
    };
    if (npc.initiative.dice=='d20'){
        initiative.textContent = 'Initiative: ' + npc.initiative.dice;
    };
    speed.textContent = 'Speed: ' + npc.speed;
    // Using loops to collect and diosplay all of the information in the object
    attacks.textContent = 'Attacks: ';
    var attackNum = Object.keys(npc.attacks).length;
    for(i = 0; i < attackNum; i++){
        var attackAttr = 'npc.attacks.' + Object.keys(npc.attacks)[i] + '.verbose';
        var s = document.createElement("div");
        s.textContent += eval(attackAttr);
        attacks.appendChild(s);
    };
    attributes.textContent = 'Attributes: '; 
    var attrNum = Object.keys(npc.attributes).length;
    for(i = 0;i < attrNum; i++){
        var attr = 'npc.attributes.' + Object.keys(npc.attributes)[i];
        var s = document.createElement("div");
        s.textContent += Object.keys(npc.attributes)[i] + ' ' + eval(attr);
        attributes.appendChild(s);
    };
    banes.textContent = 'Banes: ';
    var baneNum = Object.keys(npc.banes).length;
    for(i = 0;i < baneNum; i++){
        if (Object.keys(npc.banes)[i]!='Forced Move' && // Wasnt added because the format changed to npc.banes[""data""].
        Object.keys(npc.banes)[i]!='Persistent Damage' &&
        Object.keys(npc.banes)[i]!='Mind Dredge' &&
        Object.keys(npc.banes)[i]!='Memory Alteration'){
        var bane = 'npc.banes.' + Object.keys(npc.banes)[i];
        var baneAttrNum = Object.keys(eval(bane)).length;
        for(x = 0; x < baneAttrNum; x++){
            var baneAttr = bane + '.' + Object.keys(eval(bane))[x] + '.verbose';
            var s = document.createElement('div');
            s.textContent += Object.keys(npc.banes)[i] + ': ' + eval(baneAttr);
            banes.appendChild(s);
            };
        };
    };
    boons.textContent = 'Boons: ';
    var boonNum = Object.keys(npc.boons).length;
    for(i = 0;i < boonNum;i++){
        if (Object.keys(npc.boons)[i]!='Absorb Object' &&
            Object.keys(npc.boons)[i]!='Summon Creature' &&
            Object.keys(npc.boons)[i]!='Life Drain'){
            var boon = 'npc.boons.' + Object.keys(npc.boons)[i];
            var boonAttrNum = Object.keys(eval(boon)).length;
            for(x = 0;x < boonAttrNum; x++){
                var boonAttr = boon + '.' + Object.keys(eval(boon))[x] + '.verbose';
                var s = document.createElement('div');
                s.textContent += Object.keys(npc.boons)[i] + ': ' + eval(boonAttr);
                boons.appendChild(s);
            };
        };

    };
    // Code for dice rolling
    // In 'Open Legend' when you roll the highest possible on a dice you re-roll and add it to the total.
    // Math.floor/Math.random was learnt here: https://www.geeksforgeeks.org/javascript-math-random-function/
    PL1.addEventListener("click",
    function (e){
        var final=0;
        var min=1;
        var max20=21;
        var maxAttr=5;
        while (d20!=max20){
            var d20 = Math.floor(Math.random() * (max20 - min) + min);
            final += d20;
            if(d20<max20-1){
                break;
            };
        };
        while (attr!=maxAttr){
            var attr = Math.floor(Math.random() * (maxAttr - min) + min);
            final += attr;
            if(attr<maxAttr-1){
                break;
            };
        };
        let disp = document.querySelector('#display');
        disp.textContent = 'Roll: ' + final;
    });
    PL2.addEventListener("click",
    function (e){
        var final=0;
        var min=1;
        var max20=21;
        var maxAttr=7;
        while (d20!=max20){
            var d20 = Math.floor(Math.random() * (max20 - min) + min);
            final += d20;
            if(d20<max20-1){
                break;
            };
        };
        while (attr!=maxAttr){
            var attr = Math.floor(Math.random() * (maxAttr - min) + min);
            final += attr;
            if(attr<maxAttr-1){
                break;
            };
        };
        let disp = document.querySelector('#display');
        disp.textContent = 'Roll: ' + final;
    });
    PL3.addEventListener("click",
    function (e){
        var final=0;
        var min=1;
        var max20=21;
        var maxAttr=9;
        while (d20!=max20){
            var d20 = Math.floor(Math.random() * (max20 - min) + min);
            final += d20;
            if(d20<max20-1){
                break;
            };
        };
        while (attr!=maxAttr){
            var attr = Math.floor(Math.random() * (maxAttr - min) + min);
            final += attr;
            if(attr<maxAttr-1){
                break;
            };
        };
        let disp = document.querySelector('#display');
        disp.textContent = 'Roll: ' + final;
    });
    PL4.addEventListener("click",
    function (e){
        var final=0;
        var min=1;
        var max20=21;
        var maxAttr=11;
        while (d20!=max20){
            var d20 = Math.floor(Math.random() * (max20 - min) + min);
            final += d20;
            if(d20<max20-1){
                break;
            };
        };
        while (attr!=maxAttr){
            var attr = Math.floor(Math.random() * (maxAttr - min) + min);
            final += attr;
            if(attr<maxAttr-1){
                break;
            };
        };
        let disp = document.querySelector('#display');
        disp.textContent = 'Roll: ' + final;
    });
    PL5.addEventListener("click",
    function (e){
        var final=0;
        var min=1;
        var max20=21;
        var maxAttr=7;
        while (d20!=max20){
            var d20 = Math.floor(Math.random() * (max20 - min) + min);
            final += d20;
            if(d20<max20-1){
                break;
            };
        };
        for(i = 0;i < 2;i++){
            while (attr!=maxAttr){
                var attr = Math.floor(Math.random() * (maxAttr - min) + min);
                final += attr;
                if(attr<maxAttr-1){
                    break;
                };
            };
        };
        let disp = document.querySelector('#display');
        disp.textContent = 'Roll: ' + final;
    });
    PL6.addEventListener("click",
    function (e){
        var final=0;
        var min=1;
        var max20=21;
        var maxAttr=9;
        while (d20!=max20){
            var d20 = Math.floor(Math.random() * (max20 - min) + min);
            final += d20;
            if(d20<max20-1){
                break;
            };
        };
        for(i = 0;i < 2;i++){
            while (attr!=maxAttr){
                var attr = Math.floor(Math.random() * (maxAttr - min) + min);
                final += attr;
                if(attr<maxAttr-1){
                    break;
                };
            };
        };
        let disp = document.querySelector('#display');
        disp.textContent = 'Roll: ' + final;
    });
    PL7.addEventListener("click",
    function (e){
        var final=0;
        var min=1;
        var max20=21;
        var maxAttr=11;
        while (d20!=max20){
            var d20 = Math.floor(Math.random() * (max20 - min) + min);
            final += d20;
            if(d20<max20-1){
                break;
            };
        };
        for(i = 0;i < 2;i++){
            while (attr!=maxAttr){
                var attr = Math.floor(Math.random() * (maxAttr - min) + min);
                final += attr;
                if(attr<maxAttr-1){
                    break;
                };
            };
        };
        let disp = document.querySelector('#display');
        disp.textContent = 'Roll: ' + final;
    });
    PL8.addEventListener("click",
    function (e){
        var final=0;
        var min=1;
        var max20=21;
        var maxAttr=9;
        while (d20!=max20){
            var d20 = Math.floor(Math.random() * (max20 - min) + min);
            final += d20;
            if(d20<max20-1){
                break;
            };
        };
        for(i = 0;i < 3;i++){
            while (attr!=maxAttr){
                var attr = Math.floor(Math.random() * (maxAttr - min) + min);
                final += attr;
                if(attr<maxAttr-1){
                    break;
                };
            };
        };
        let disp = document.querySelector('#display');
        disp.textContent = 'Roll: ' + final;
    });
    PL9.addEventListener("click",
    function (e){
        var final=0;
        var min=1;
        var max20=21;
        var maxAttr=11;
        while (d20!=max20){
            var d20 = Math.floor(Math.random() * (max20 - min) + min);
            final += d20;
            if(d20<max20-1){
                break;
            };
        };
        for(i = 0;i < 3;i++){
            while (attr!=maxAttr){
                var attr = Math.floor(Math.random() * (maxAttr - min) + min);
                final += attr;
                if(attr<maxAttr-1){
                    break;
                };
            };
        };
        let disp = document.querySelector('#display');
        disp.textContent = 'Roll: ' + final;
    });
    PL10.addEventListener("click",
    function (e){
        var final=0;
        var min=1;
        var max20=21;
        var maxAttr=9;
        while (d20!=max20){
            var d20 = Math.floor(Math.random() * (max20 - min) + min);
            final += d20;
            if(d20<max20-1){
                break;
            };
        };
        for(i = 0;i < 3;i++){
            while (attr!=maxAttr){
                var attr = Math.floor(Math.random() * (maxAttr - min) + min);
                final += attr;
                if(attr<maxAttr-1){
                    break;
                };
            };
        };
        let disp = document.querySelector('#display');
        disp.textContent = 'Roll: ' + final;
    });
});
